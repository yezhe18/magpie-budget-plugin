# Reproduce the offline plugin

This archive includes the actual source inputs for the linked cores and JavaScript dependencies. Upstream commits are recorded in magpie-budget-plugin/upstream-pins.json.

Use Node 24 for the build. To recreate the locked build tools, run:

    cd magpie-budget-plugin/build
    npm ci --ignore-scripts --no-audit --no-fund
    cd ..
    node scripts/build.mjs
    node scripts/stage-native.mjs

The source trees antseed/ and freellmapi-core/ must remain beside magpie-budget-plugin/. esbuild does not type-check imports; all non-type inputs and alias package manifests are included. Build dependencies are for rebuilding only and are not runtime dependencies. Native staging is build-time only and verifies the exact release archive hashes.
