// Moved to @antseed/buyer-core; re-exported for compatibility.
export * from '@antseed/buyer-core/deposits-client';
