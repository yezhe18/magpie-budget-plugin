import fs from 'node:fs/promises';
import path from 'node:path';
import { AntseedNode } from '../../antseed/packages/node/src/node.js';
import { LocalRouter } from '../../antseed/plugins/router-local/src/router.js';
import { BuyerProxy } from '../../antseed/apps/cli/src/proxy/buyer-proxy.js';
import { buildPaymentsConfig } from '../../antseed/apps/cli/src/cli/commands/network/chain-config-helper.js';

export { AntseedNode, BuyerProxy, LocalRouter };
export { ConnectionManager } from '../../antseed/packages/node/src/p2p/connection-manager.js';
export { NatTraversal } from '../../antseed/packages/node/src/p2p/nat-traversal.js';
export { identityFromPrivateKeyHex } from '../../antseed/packages/node/src/p2p/identity.js';
export { CONNECTION_CAPABILITY_WEBRTC_V1, CONNECTION_CAPABILITY_TCP_ENC_V1 } from '../../antseed/packages/node/src/types/protocol.js';
export { ANTSEED_STREAMING_RESPONSE_HEADER } from '../../antseed/packages/node/src/types/http.js';

export async function startAntseed(directory: string, options: any = {}) {
  await fs.mkdir(directory, { recursive: true, mode: 0o700 });
  const paid = options.payments?.enabled !== false;
  if (paid && !options.router?.maxPricing?.defaults) throw new Error('AntSeed paid mode requires router.maxPricing.defaults with input/output USD per million limits.');
  if (paid && ['inputUsdPerMillion', 'outputUsdPerMillion'].some(k => !Number.isFinite(options.router.maxPricing.defaults[k]) || options.router.maxPricing.defaults[k] < 0)) throw new Error('AntSeed price limits must be finite nonnegative numbers.');
  const chain = paid ? buildPaymentsConfig(options.crypto) : undefined;
  if (paid && !chain) throw new Error('AntSeed chain configuration cannot be resolved.');
  const node = new AntseedNode({ ...options.node, role: 'buyer', dataDir: directory,
    payments: paid ? { ...chain!, defaultDepositAmountUSDC: '1000000', maxPerRequestUsdc: '300000', maxReserveAmountUsdc: '1000000', ...options.payments, enabled: true } : { enabled: false },
    verification: options.verification });
  node.setRouter(new LocalRouter(options.router));
  let proxy: BuyerProxy | undefined;
  try {
    await node.start();
    proxy = new BuyerProxy({ ...options.proxy, node, dataDir: directory, port: 0 });
    await proxy.start();
    const files = await fs.readdir(directory);
    const control = files.find(x => x.includes('control') && x.endsWith('.json'));
    let port = 0;
    if (control) { const metadata = JSON.parse(await fs.readFile(path.join(directory, control), 'utf8')); port = metadata.proxyPort || metadata.port || 0; }
    // This upstream revision has no public ephemeral-port accessor.
    if (!port) port = (proxy as any)._server.address().port;
    return { baseURL: `http://127.0.0.1:${port}`, status: () => ({ state: 'running', peerId: node.peerId, payments: paid }),
      async close() { await proxy!.stop(); await node.stop(); } };
  } catch (error) { if (proxy) await proxy.stop().catch(() => {}); await node.stop().catch(() => {}); throw error; }
}
