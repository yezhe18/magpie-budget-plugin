import fs from 'node:fs/promises';
import path from 'node:path';
import { randomBytes, createHash } from 'node:crypto';
import { createApp } from '../../freellmapi-core/server/src/app.js';
import { initDb, getDb, getUnifiedApiKey, getSetting, setSetting } from '../../freellmapi-core/server/src/db/index.js';
import { builtinSqliteFactory } from './sqlite.js';
import { loadConfig } from '../../freellmapi-core/server/src/lib/config.js';
import { applyDeclarativeConfig } from '../../freellmapi-core/server/src/services/declarative-config.js';
import { startHealthChecker, stopHealthChecker, checkAllKeys } from '../../freellmapi-core/server/src/services/health.js';
import { startCatalogSync, stopCatalogSync } from '../../freellmapi-core/server/src/services/catalog-sync.js';
import { startCooldownProbe, stopCooldownProbe } from '../../freellmapi-core/server/src/services/cooldown-probe.js';
import { startCustomModelSync } from '../../freellmapi-core/server/src/services/custom-model-sync.js';
import { startBuiltinModelDiscovery } from '../../freellmapi-core/server/src/services/builtin-model-discovery.js';
import { startDbBackupPump } from '../../freellmapi-core/server/src/lib/db-backup.js';
import { startBackupScheduler } from '../../freellmapi-core/server/src/services/backups.js';
import { loadCacheFromDb } from '../../freellmapi-core/server/src/services/cache.js';
import { cleanupExpiredCooldowns } from '../../freellmapi-core/server/src/services/ratelimit.js';
import { restoreProxySettings, flushProxyCache } from '../../freellmapi-core/server/src/lib/proxy.js';
import { startWakeDetect, stopWakeDetect } from '../../freellmapi-core/server/src/lib/wake-detect.js';
import { installLogRedaction } from '../../freellmapi-core/server/src/lib/log-redaction.js';
import { restrictAllToOwner, restrictDirToOwner } from '../../freellmapi-core/server/src/lib/file-permissions.js';

class OwnedScheduler {
  timers = new Set<ReturnType<typeof setTimeout>>();
  every(ms: number, fn: () => unknown) { const id = setInterval(() => Promise.resolve().then(fn).catch(e => console.error('[free scheduler]', e.message)), ms); this.timers.add(id); return () => { clearInterval(id); this.timers.delete(id); }; }
  after(ms: number, fn: () => unknown) { const id = setTimeout(() => { this.timers.delete(id); Promise.resolve().then(fn).catch(e => console.error('[free scheduler]', e.message)); }, ms); this.timers.add(id); return () => { clearTimeout(id); this.timers.delete(id); }; }
  close() { for (const id of this.timers) clearInterval(id); this.timers.clear(); }
}

export async function startFree(directory: string, options: any = {}) {
  // The offline plugin forwards original images. It deliberately omits
  // sharp's optional native image-resizing dependency.
  process.env.IMAGE_NORMALIZE ??= 'off';
  await fs.mkdir(directory, { recursive: true, mode: 0o700 });
  if (!restrictDirToOwner(directory)) throw new Error('Cannot protect FreeLLMAPI directory');
  const keyFile = path.join(directory, 'encryption.key');
  try { await fs.writeFile(keyFile, randomBytes(32).toString('hex'), { flag: 'wx', mode: 0o600 }); }
  catch (e: any) { if (e.code !== 'EEXIST') throw e; }
  restrictAllToOwner([keyFile]);
  process.env.ENCRYPTION_KEY = (await fs.readFile(keyFile, 'utf8')).trim();
  process.env.FREEAPI_DB_DIR_HARDENING = '1';
  installLogRedaction();
  const dbPath = path.join(directory, 'freeapi.db');
  const db = initDb(dbPath, { factory: builtinSqliteFactory });
  const scheduler = new OwnedScheduler();
  let server: any;
  try {
    const declared = options.config || {};
    const fingerprint = createHash('sha256').update(JSON.stringify(declared)).digest('hex');
    if (getSetting('budget_declarative_revision') !== fingerprint) {
      const result = applyDeclarativeConfig(declared, 'managed-plugin');
      if (result.warnings.length) throw new Error('FreeLLMAPI config rejected: ' + result.warnings.join('; '));
      setSetting('budget_declarative_revision', fingerprint);
    }
    loadCacheFromDb(); cleanupExpiredCooldowns(); restoreProxySettings();
    const app = createApp({ ...loadConfig(), host: '127.0.0.1', port: 0, dbPath, nodeEnv: 'production', serveStaticAssets: false, trustProxy: false });
    server = app.listen(0, '127.0.0.1');
    await new Promise<void>((resolve, reject) => { server.once('listening', resolve); server.once('error', reject); });
    const baseURL = `http://127.0.0.1:${server.address().port}`;
    if (options.background !== false) {
      startHealthChecker(scheduler); startCatalogSync(scheduler); startCooldownProbe(scheduler);
      startDbBackupPump(getDb(), scheduler, dbPath); startBackupScheduler(scheduler);
      startCustomModelSync(db, scheduler); startBuiltinModelDiscovery(db, scheduler);
      startWakeDetect({ onWake: async () => { flushProxyCache(); await checkAllKeys({ force: true }); } });
    }
    if (options.probeOnStart === true) await checkAllKeys({ force: true });
    return { baseURL, apiKey: getUnifiedApiKey(), status: () => ({ state: 'running', database: dbPath }),
      async close() {
        stopHealthChecker(); stopCatalogSync(); stopCooldownProbe(); stopWakeDetect(); scheduler.close(); flushProxyCache();
        server.closeIdleConnections?.();
        await new Promise<void>(resolve => server.close(() => resolve()));
        db.close?.();
      } };
  } catch (error) {
    scheduler.close(); if (server?.listening) await new Promise<void>(r => server.close(() => r())); db.close?.(); throw error;
  }
}
