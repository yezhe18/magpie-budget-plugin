export { restrictDirToOwner, restrictToOwner } from '../../freellmapi-core/server/src/lib/file-permissions.js';
