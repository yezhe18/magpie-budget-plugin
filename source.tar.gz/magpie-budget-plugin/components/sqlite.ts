import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const isBun = typeof (globalThis as any).Bun !== 'undefined';

/** The synchronous SQLite contract used by both upstream cores. */
export default class BuiltinDatabase {
  private raw: any;
  private depth = 0;
  private sequence = 0;
  name: string;
  memory: boolean;
  open = true;
  constructor(filename: string) {
    this.name = filename;
    this.memory = filename === ':memory:';
    this.raw = isBun
      ? new (require('bun:sqlite').Database)(filename, { create: true, strict: true })
      : new (require('node:sqlite').DatabaseSync)(filename);
  }
  get inTransaction() { return this.depth > 0; }
  prepare(sql: string) {
    const statement = this.raw.prepare(sql);
    // Match better-sqlite3's unprefixed named-parameter objects on Bun.
    const parameters = (...args: any[]) => isBun && args.length === 1 && args[0] &&
      typeof args[0] === 'object' && !Array.isArray(args[0]) && !ArrayBuffer.isView(args[0])
      ? [Object.fromEntries(Object.entries(args[0]).map(([k, v]) => [k, v]))] : args;
    return {
      get: (...args: any[]) => statement.get(...parameters(...args)) ?? undefined,
      all: (...args: any[]) => statement.all(...parameters(...args)),
      run: (...args: any[]) => {
        const result = statement.run(...parameters(...args));
        const changes = Number(result.changes), lastInsertRowid = Number(result.lastInsertRowid);
        if (!Number.isSafeInteger(changes) || !Number.isSafeInteger(lastInsertRowid)) throw new Error('SQLite integer exceeds safe range');
        return { changes, lastInsertRowid };
      },
    };
  }
  exec(sql: string) { this.raw.exec(sql); return this; }
  pragma(source: string, options: { simple?: boolean } = {}) {
    const rows = this.raw.prepare('PRAGMA ' + source).all();
    return options.simple ? Object.values(rows[0] || {})[0] : rows;
  }
  transaction(fn: (...args: any[]) => any) {
    const db = this;
    const run = (mode: string) => function (this: any, ...args: any[]) {
      const outer = db.depth === 0, savepoint = 'budget_tx_' + ++db.sequence;
      db.raw.exec(outer ? 'BEGIN ' + mode : 'SAVEPOINT ' + savepoint);
      db.depth++;
      try {
        const result = fn.apply(this, args);
        if (result && typeof result.then === 'function') throw new Error('SQLite transaction callbacks must be synchronous');
        db.raw.exec(outer ? 'COMMIT' : 'RELEASE SAVEPOINT ' + savepoint);
        return result;
      } catch (error) {
        try { db.raw.exec(outer ? 'ROLLBACK' : 'ROLLBACK TO SAVEPOINT ' + savepoint + '; RELEASE SAVEPOINT ' + savepoint); }
        catch { /* Keep the callback or commit error. */ }
        throw error;
      } finally { db.depth--; }
    };
    const wrapped: any = run('DEFERRED');
    wrapped.deferred = wrapped; wrapped.immediate = run('IMMEDIATE'); wrapped.exclusive = run('EXCLUSIVE');
    return wrapped;
  }
  close() { if (this.open) { this.raw.close(); this.open = false; } }
}
export const builtinSqliteFactory = (filename: string) => new BuiltinDatabase(filename);
