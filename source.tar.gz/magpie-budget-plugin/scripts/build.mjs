import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const workspace = path.resolve(root, '..');
const modules = process.env.BUDGET_BUILD_MODULES || path.join(root, 'build/node_modules');
const { build } = createRequire(path.join(modules, '../package.json'))('esbuild');
const packages = new Map();
for (const name of ['node', 'buyer-core', 'protocol', 'api-adapter', 'router-core', 'provider-core']) {
  const dir = path.join(workspace, 'antseed/packages', name);
  packages.set('@antseed/' + name, { dir, json: JSON.parse(await fs.readFile(path.join(dir, 'package.json'), 'utf8')) });
}
const aliases = { name: 'pinned-core-source', setup(b) {
  b.onResolve({ filter: /^better-sqlite3$/ }, () => ({ path: path.join(root, 'components/sqlite.ts') }));
  b.onResolve({ filter: /^@antseed\// }, args => {
    const [scope, name, ...sub] = args.path.split('/');
    const p = packages.get(`${scope}/${name}`);
    if (!p) throw new Error('Unexpected AntSeed package: ' + args.path);
    const ex = p.json.exports?.[sub.length ? './' + sub.join('/') : '.'];
    const file = typeof ex === 'string' ? ex : ex?.import || (sub.length ? `dist/${sub.join('/')}.js` : p.json.main);
    return { path: path.join(p.dir, file.replace(/^\.\//, '').replace(/^dist\//, 'src/').replace(/\.js$/, '.ts')) };
  });
  b.onResolve({ filter: /^@freellmapi\/shared$/ }, () => ({ path: path.join(workspace, 'freellmapi-core/shared/types.ts') }));
} };
await fs.mkdir(path.join(root, 'dist'), { recursive: true });
for (const component of ['free', 'antseed', 'permissions', 'sqlite']) {
  const result = await build({ absWorkingDir: workspace,
    entryPoints: [path.join(root, 'components', component + '.ts')], outfile: path.join(root, 'dist', component + '.mjs'),
    bundle: true, platform: 'node', format: 'esm', target: 'node22', minify: true, legalComments: 'linked', metafile: true,
    banner: { js: 'import { createRequire as __createRequire } from "node:module"; const require = __createRequire(import.meta.url);' },
    external: ['node-datachannel', 'keytar', 'sharp', 'bun:sqlite'],
    plugins: [aliases], nodePaths: [modules], logLevel: 'warning' });
  await fs.writeFile(path.join(root, 'dist', component + '-sources.json'), JSON.stringify(result.metafile, null, 2));
}
console.log('Bundled pinned cores; no npm installation is needed at runtime.');
