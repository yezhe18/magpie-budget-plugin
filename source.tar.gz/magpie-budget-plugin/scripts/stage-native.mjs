// Build-time only. The distributable already contains both verified binaries.
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const modules = process.env.BUDGET_BUILD_MODULES || path.join(root, 'build/node_modules');
const manifest = JSON.parse(await fs.readFile(path.join(root, 'native-artifacts.json'), 'utf8'));
const ndc = path.join(root, 'node_modules/node-datachannel');
await fs.mkdir(path.join(ndc, 'lib'), { recursive: true });
for (const file of ['index.js', 'index.cjs', 'datachannel-stream.js']) {
  const original = await fs.readFile(path.join(modules, 'node-datachannel/lib', file), 'utf8');
  await fs.writeFile(path.join(ndc, 'lib', file), original.replace("'../build/Release/node_datachannel.node'", "'../../../native/' + process.platform + '-' + process.arch + '/node_datachannel.node'"));
}
const meta = JSON.parse(await fs.readFile(path.join(modules, 'node-datachannel/package.json'), 'utf8'));
for (const key of ['dependencies', 'devDependencies', 'scripts']) delete meta[key];
delete meta.exports['./polyfill'];
await fs.writeFile(path.join(ndc, 'package.json'), JSON.stringify(meta, null, 2) + '\n');
for (const file of await fs.readdir(path.join(modules, 'node-datachannel'))) {
  if (/license|notice/i.test(file)) await fs.copyFile(path.join(modules, 'node-datachannel', file), path.join(ndc, file));
}
const temporary = await fs.mkdtemp(path.join(os.tmpdir(), 'budget-native-build-'));
try {
  for (const artifact of manifest.artifacts) {
    const response = await fetch(artifact.url); if (!response.ok) throw new Error('Download failed: ' + response.status);
    const bytes = Buffer.from(await response.arrayBuffer());
    if (createHash('sha256').update(bytes).digest('hex') !== artifact.sha256) throw new Error('Native archive checksum mismatch');
    const archive = path.join(temporary, artifact.platform + '.tgz'); await fs.writeFile(archive, bytes);
    const payload = execFileSync('tar', ['-xOf', archive, artifact.member], { maxBuffer: 32 * 1024 * 1024 });
    const directory = path.join(root, 'native', artifact.platform); await fs.mkdir(directory, { recursive: true });
    await fs.writeFile(path.join(directory, path.basename(artifact.member)), payload);
  }
} finally { await fs.rm(temporary, { recursive: true, force: true }); }
console.log('Staged pinned native files for the offline distribution.');
